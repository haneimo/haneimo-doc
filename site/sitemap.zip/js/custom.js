// filepath: /home/haneimo/workspace/haneimo-doc/js/custom.js
(function() {
    var script = document.createElement('script');
    script.async = true;
    script.src = "https://pagead2.googlesyndication.com/pagead/js/adsbygoogle.js?client=ca-pub-3874515773493908";
    script.crossOrigin = "anonymous";
    document.head.appendChild(script);
    console.log("load ads");
})();